<?php

use yii\db\Schema;
use yii\db\Migration;

/**
 * Handles the creation of table `category`.
 */
class m181026_123916_create_category_table extends Migration
{
    /**
     * {@inheritdoc}
     */
   
	
	   public function up()
    {
        $this->createTable('category', [
            'id' => Schema::TYPE_PK,
            'parent_id' => Schema::TYPE_INTEGER.' DEFAULT 0',
            'name' => Schema::TYPE_STRING.' NOT NULL'            
        ]);
    }

    /**
     * @inheritdoc
     */
    public function down()
    {
        $this->dropTable('category');
    }
}
