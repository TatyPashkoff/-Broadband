<?php

/* @var $this yii\web\View */

$this->title = 'меню категорий';
?>
<style>
   .ex {
    border: dashed 1px #634F36;
    background: #fffff5;
    font-family: "Courier New", Courier, monospace; 
    padding: 7px;
    font-size: 80%;
    margin: 0 0 1em;
   }
  </style>
<div class="site-index">

    <div class="jumbotron">
    </div>

    <div class="body-content">

        <div class="row">
            <div class="col-lg-4">
                <h2>Категории</h2>

                <p><?= app\components\MenuWidget::widget(['tpl' => 'menu']) ?>
                    </p>

                
            </div>
            <div class="col-lg-6">
                <h2>Задача:</h2>

				
                <p>С использованием функции preg_replace убрать все "лишние" нули после точки. Пример: 55.100, 55.01, 50.001, 55.0010, 50.00</p>
				
				<p class="ex"> 
				$value = array(5.100, 55.01, 50.001, 55.0010, 50.00);<br>

				foreach($value as $val )<br>
				{<br>
					echo $val . ' -> ' . preg_replace('#\.?0+$#', '', sprintf('%01.3f', $val)); <br>
				}<br>
				</p>
				
				Результат:<br>
				
				<?php 
				$value = array(5.100, 55.01, 50.001, 55.0010, 50.00);

				foreach($value as $val )
				{
					echo preg_replace('#\.?0+$#', '', sprintf('%01.3f', $val)) .  '<br>' ; 
				}
				?>
               
            </div>
            
        </div>

    </div>
</div>
